document.getElementById("menuBtn").onclick = () => {
  document.getElementById("sideMenu").classList.toggle("hidden");
};

document.getElementById("searchBtn").onclick = () => {
  alert("ميزة البحث سيتم إضافتها لاحقًا.");
};